<?php

class Defesa extends Item {
    public function _construct($nome) {
    parent::_construct($nome, 4);

    }
}   