<?php

class Magica extends Item {
    public function _construct($nome) {
        parent:: _construct($nome, 2);

        }
 }