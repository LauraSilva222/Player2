<?php

 class Player {
    private $nickname;
    private $nivel;
    private $inventario;
  
    public function __construct($nickname, $nivel = 1) {
      $this->nickname = $nickname;
      $this->nivel = $nivel;
      $this->inventario = new Inventario(10);
    }
  
    public function getNickname() { return $this->nickname; }
    public function getNivel() { return $this->nivel; }
    public function getInventario() { return $this->inventario; }
  
    public function setNickname($nickname) { $this->nickname = $nickname; }
    public function setNivel($nivel) { $this->nivel = $nivel; }
  
    public function coletarItem($item) { $this->inventario->adicionarItem($item); }
    public function soltarItem($item) { $this->inventario->removerItem($item); }
    public function subirNivel() { $this->nivel++; }
  }
  
  class Inventario {
    private $capacidadeMaxima;
    private $itens;
  
    public function __construct($capacidadeMaxima) {
      $this->capacidadeMaxima = $capacidadeMaxima;
      $this->itens = array();
    }
  
    public function getCapacidadeMaxima() { return $this->capacidadeMaxima; }
    public function getItens() { return $this->itens; }
  
    public function setCapacidadeMaxima($capacidadeMaxima) { $this->capacidadeMaxima = $capacidadeMaxima; }
  
    public function adicionarItem($item) {
      if (count($this->itens) < $this->capacidadeMaxima) {
        array_push($this->itens, $item);
      }
    }
  
    public function removerItem($item) {
      $this->itens = array_diff($this->itens, array($item));
    }
  
    public function capacidadeLivre() {
      return $this->capacidadeMaxima - count($this->itens);
    }
  }
  
  class Item {
    private $nome;
    private $tamanho;
    private $classe;
  
    public function __construct($nome, $tamanho, $classe) {
      $this->nome = $nome;
      $this->tamanho = $tamanho;
      $this->classe = $classe;
    }
  
    public function getNome() { return $this->nome; }
    public function getTamanho() { return $this->tamanho; }
    public function getClasse() { return $this->classe; }
  
    public function setNome($nome) { $this->nome = $nome; }
    public function setTamanho($tamanho) { $this->tamanho = $tamanho; }
    public function setClasse($classe) { $this->classe = $classe; }
  }

  class Ataque extends Item {
    private $dano;
    private $velocidade;
  
    public function __construct($nome, $tamanho, $classe, $dano, $velocidade) {
      parent::__construct($nome, $tamanho, $classe);
      $this->dano = $dano;
      $this->velocidade = $velocidade;
    }
  
    public function getDano() { return $this->dano; }
    public function getVelocidade() { return $this->velocidade; }
  
    public function setDano($dano) { $this->dano = $dano; }
    public function setVelocidade($velocidade) { $this->velocidade = $velocidade; }
  }

  class Defesa extends Item {
    private $resistencia;
    private $bloqueio;
  
    public function __construct($nome, $tamanho, $classe, $resistencia, $bloqueio) {
      parent::__construct($nome, $tamanho, $classe);
      $this->resistencia = $resistencia;
      $this->bloqueio = $bloqueio;
    }
  
    public function getResistencia() { return $this->resistencia; }
    public function getBloqueio() { return $this->bloqueio; }
  
    public function setResistencia($resistencia) { $this->resistencia = $resistencia; }
    public function setBloqueio($bloqueio) { $this->bloqueio = $bloqueio; }
  }
  
  class Magia extends Item {
    private $danoMagico;
    private $alcance;
    private $custoMana;
  
    public function __construct($nome, $tamanho, $classe, $danoMagico, $alcance, $custoMana) {
      parent::__construct($nome, $tamanho, $classe);
      $this->danoMagico = $danoMagico;
      $this->alcance = $alcance;
      $this->custoMana = $custoMana;
    }
  
    public function getDanoMagico() { return $this->danoMagico; }
    public function getAlcance() { return $this->alcance; }
    public function getCustoMana() { return $this->custoMana; }
  
    public function setDanoMagico($danoMagico) { $this->danoMagico = $danoMagico; }
    public function setAlcance($alcance) { $this->alcance = $alcance; }
    public function setCustoMana($custoMana) { $this->custoMana = $custoMana; }
  }