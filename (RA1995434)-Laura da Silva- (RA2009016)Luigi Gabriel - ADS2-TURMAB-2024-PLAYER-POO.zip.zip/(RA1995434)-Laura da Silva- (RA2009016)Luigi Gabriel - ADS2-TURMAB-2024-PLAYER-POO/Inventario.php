<?php

class Inventario {
    private $capacidadeMaxima;
    private $itens;
  
    public function __construct($capacidade) {
      $this->capacidadeMaxima = $capacidade;
      $this->itens = [];
    }
  
    public function getCapacidade() { return $this->capacidadeMaxima; }
    public function getItens() { return $this->itens; }
  
    public function setCapacidade($capacidade) { $this->capacidadeMaxima = $capacidade; }
  
    public function adicionar($item) {
      if (count($this->itens) < $this->capacidadeMaxima) {
        $this->itens[] = $item;
      }
    }
  
    public function remover($item) {
      $this->itens = array_diff($this->itens, [$item]);
    }
  
    public function capacidadeLivre() {
      return $this->capacidadeMaxima - count($this->itens);
    }
  }